<?php

class Warmer_Model extends Base_Model {

    public function get_data( $id ) {
       
    }

    public function store_data( $data ) {
        
    }

}